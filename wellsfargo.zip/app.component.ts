import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  LstName; descript; priorit; Twostatus; dDate; tskTitl; hideit = true;
  taskList = [{"title":"Task 1", "priority":"Normal", 
              "status":"ToDo", "DueDate":"06/02/2016",
              "DateCreated":"05/01/2016 2:33 PM",
              "DateModified":"05/02/2016 1:22 PM"},

              {"title":"Task 2", "priority":"Major", 
              "status":"InProgress", "DueDate":"05/02/2016",
              "DateCreated":"05/01/2016 2:33 PM",
              "DateModified":"05/02/2016 1:22 PM"},
            
              {"title":"Task 3", "priority":"Critical", 
              "status":"Done", "DueDate":"05/02/2016",
              "DateCreated":"05/01/2016 2:33 PM",
              "DateModified":"05/02/2016 1:22 PM"}];

  show(){
    this.hideit = false;
  }
  Click(data){
   let temp = {
    "title": data.ListName,
    "priority":data.prio,
    "status":data.status,
    "DueDate":data.due,
    "DateCreated":new Date().toLocaleDateString(),
    "DateModified":new Date().toLocaleDateString()
    }
    for(let task1 of this.taskList){
     if(data.taskTitle == task1.title){
     this.taskList.splice((this.taskList.indexOf(task1)+1),0,temp);
     }
     else{ console.log("hi");
     this.taskList.push(temp);
     break;
    }

    }
  }

  Edit(val){
    this.hideit = false;
    this.LstName = this.taskList[val].title;
    this.priorit = this.taskList[val].priority;
    this.Twostatus = this.taskList[val].status; 
    this.taskList.splice(val,1);
  }

  Delete(value){
    for(let i in this.taskList){
      if(this.taskList[i].title == value){
        this.taskList.splice(parseInt(i),1);
      }
    }
  }
  Cancel(){
    this.LstName = "";
    this.descript = "";
    this.priorit = "";
    this.Twostatus = "";
    this.dDate = ""; 
    this.tskTitl = ""; 
    this.hideit = true;
  }
}
